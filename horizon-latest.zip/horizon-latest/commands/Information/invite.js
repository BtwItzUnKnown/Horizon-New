const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");

module.exports = {
    name: "invite",
    category: "Information",
    aliases: [ "addme" ],
    description: "Invite Horizon",
    args: false,
    usage: "",
    permission: [],
    owner: false,
   execute: async (message, args, client, prefix) => {
         
         
    const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
    .setLabel("Invite Me!")
    .setStyle("LINK")
    .setURL(`https://discord.com/api/oauth2/authorize?client_id=899695298010550293&permissions=6479539264&scope=applications.commands%20bot`),
    new MessageButton()
    .setLabel("Support Server!")
    .setStyle("LINK")
    .setURL("https://discord.gg/6mrw9ebbYQ")
			);

          const mainPage = new MessageEmbed()
           .setAuthor(`Horizon`, client.user.displayAvatarURL({ dynamic: true }))
            .setThumbnail(client.user.displayAvatarURL())
             .setColor(client.embedColor)
            .setDescription(`
› Want to invite me in your server [click here](https://discord.com/api/oauth2/authorize?client_id=899695298010550293&permissions=6479539264&scope=applications.commands%20bot)
› Join my support server [click here](https://discord.gg/6mrw9ebbYQ)
`)
           message.channel.send({embeds: [mainPage], components: [row]})
    }
}