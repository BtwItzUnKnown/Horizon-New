const {
    MessageEmbed,
    Message,
    Client
} = require("discord.js");
const { readdirSync } = require("fs");


module.exports = {
    name: "help",
    category: "Information",
    aliases: [ "h", "commands" ],
    description: "Return all commands, or one specific command",
    args: false,
    usage: "",
    permission: [],
    owner: false,
   execute: async (message, args, client, prefix) => {

     let color = client.embedColor;
      let categories = [];
        let cots = [];

        if (!args[0]) {

            //categories to ignore
            let ignored = [
                "Owner"
            ];

            const emo = {

        Config: "⚙️",
        Information: "ℹ️",
        Music: "🎵",
        Owner: "👑" 
            }

            let ccate = [];
           readdirSync("./commands/").forEach((dir) => {
                if (ignored.includes(dir.toLowerCase())) return;
                const commands = readdirSync(`./commands/${dir}/`).filter((file) =>
                    file.endsWith(".js")
                );

                if (ignored.includes(dir.toLowerCase())) return;

                const name = `${emo[dir]} - ${dir}`;
                
                let nome = dir.toUpperCase();

                let cats = new Object();

                //this is how it will be created as
                cats = {
                    name: name,
                    value: `\`${prefix}help ${dir.toLowerCase()}\``,
                    inline: true
                }


                categories.push(cats);
                ccate.push(nome);
            });
            //embed
            const embed = new MessageEmbed()
              
            
              .setAuthor(`Horizon Help Menu`, client.user.displayAvatarURL({ dynamic: true })) 
              
              .setThumbnail(client.user.displayAvatarURL())
                                        .setDescription(`>>> Type \`${prefix}\`\`help [command]\` for detailed info on that command.`)
            
.addFields(
      { name: '<a:Horizon_filters:899732181189001247>・ Filters', value: '`party,` `bass,` `pop,` `trablebass,` `soft,` `custom,` `off`', inline: false },
      { name: '<a:Horizon_music:899732265792311387>・ Music', value: '`autoplay,` `play,` `join,` `leave,` `loop,` `move,` `nowplaying,` `pause,` `queue,` `clearqueue,` `remove,` `resume,` `shuffle,` `seek,` `skip,` `skipto,` `stop,` `volume,` `filter`', inline: false },
      { name: '<a:Horizon_setting:899732338500567071>・Utility', value: '`help,` `ping,` `about,` `node,` `stats` ', inline: false },
  { name: '<a:Horizon_king:899731374620176435>・Owner', value: '`eval,` `shutdown`', inline: false }
)       

                          
              .setFooter(
                    `${message.author.tag}`,
                    message.author.displayAvatarURL({
                        dynamic: true
                    })
                )    
                .setTimestamp()
                .setColor(color)
            
            return message.channel.send({
                embeds: [embed]    })
                
} 
     {

            const command =
                client.commands.get(args[0].toLowerCase()) ||
                client.commands.find(
                (c) => c.aliases && c.aliases.includes(args[0].toLowerCase())
                );


            if (!command) {
                const embed = new MessageEmbed()
                    .setTitle(`Invalid command! Use \`${prefix}help\` for all of my commands!`)
                    .setColor(color);
                return await client.sendEmbed(embed);
            }

            const embed = new MessageEmbed()
               .setAuthor(`Horizon command details`, client.user.displayAvatarURL({ dynamic: true }))
                .setDescription(
"Name",
command.name ? `\`${command.name}\`` : "No name for this command.",
"Description",
command.description ? `\`${command.description}\`` : "No description for this command." 

                )
                .addField(
                    "Alias",
                    command.aliases ?
                    `\`${command.aliases.join("` `")}\`` :
                    "No aliases for this command."
                )
                .addField(
                    "Usage(s)",
                    command.usage ?
                    `\`${prefix}${command.name} ${command.usage}\`` :
                    `\`${prefix}${command.name}\``
                )
                .setFooter(
                    `${message.member.displayName}`,
                    message.author.displayAvatarURL({
                        dynamic: true
                    })
                )
                .setTimestamp()
                .setColor(client.embedColor);
            return await message.channel.send({embeds: [embed]});
        }
    },
};
                    
                             
                                                                