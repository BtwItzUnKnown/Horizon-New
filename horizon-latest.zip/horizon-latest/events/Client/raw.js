module.exports = async (client, data) => {
  client.manager.updateVoiceState(data);
};
